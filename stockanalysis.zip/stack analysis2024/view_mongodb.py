from pymongo import MongoClient
import json

# Connect to MongoDB
client = MongoClient('mongodb://localhost:27017/')

# Get a list of all databases
print("Databases:")
for db_name in client.list_database_names():
    print(f"- {db_name}")
    db = client[db_name]
    
    # Get collections in this database
    print("  Collections:")
    for collection_name in db.list_collection_names():
        print(f"  - {collection_name}")
        collection = db[collection_name]
        
        # Count documents
        count = collection.count_documents({})
        print(f"    Document count: {count}")
        
        # Show a sample document if there are any
        if count > 0:
            print("    Sample document:")
            sample = collection.find_one()
            print(json.dumps(sample, default=str, indent=4))
        
        print()

print("Done!")