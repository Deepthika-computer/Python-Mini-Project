from django.urls import path
from . import views

urlpatterns = [
    # Home and market overview
    path('', views.home, name='home'),
    
    # Stock related URLs
    path('stocks/', views.stock_list, name='stock_list'),
    path('stocks/<str:symbol>/', views.stock_detail, name='stock_detail'),
    
    # Sector related URLs
    path('sectors/', views.sector_list, name='sector_list'),
    path('sectors/<int:sector_id>/', views.sector_detail, name='sector_detail'),
    
    # Portfolio related URLs
    path('portfolios/', views.portfolio_list, name='portfolio_list'),
    path('portfolios/<int:portfolio_id>/', views.portfolio_detail, name='portfolio_detail'),
    path('portfolios/add/', views.add_portfolio, name='add_portfolio'),
    path('portfolios/<int:portfolio_id>/add-transaction/', views.add_transaction, name='add_transaction'),
    
    # Watchlist related URLs
    path('watchlists/', views.watchlist_list, name='watchlist_list'),
    path('watchlists/<int:watchlist_id>/', views.watchlist_detail, name='watchlist_detail'),
    path('watchlists/add/', views.add_watchlist, name='add_watchlist'),
    path('watchlists/add-stock/', views.add_to_watchlist, name='add_to_watchlist'),
    path('watchlists/remove-stock/', views.remove_from_watchlist, name='remove_from_watchlist'),
]