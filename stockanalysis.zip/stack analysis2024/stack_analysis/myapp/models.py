from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone
import uuid

class Sector(models.Model):
    name = models.CharField(max_length=100)
    description = models.TextField()
    
    def __str__(self):
        return self.name

class Stock(models.Model):
    symbol = models.CharField(max_length=10, unique=True)
    name = models.CharField(max_length=200)
    sector = models.ForeignKey(Sector, on_delete=models.SET_NULL, null=True, related_name='stocks')
    description = models.TextField(blank=True, null=True)
    current_price = models.DecimalField(max_digits=10, decimal_places=2, default=0.00)
    previous_close = models.DecimalField(max_digits=10, decimal_places=2, default=0.00)
    market_cap = models.BigIntegerField(default=0)
    pe_ratio = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    dividend_yield = models.DecimalField(max_digits=5, decimal_places=2, null=True, blank=True)
    last_updated = models.DateTimeField(default=timezone.now)
    
    def __str__(self):
        return f"{self.symbol} - {self.name}"
    
    def price_change(self):
        if self.previous_close == 0:
            return 0
        return ((self.current_price - self.previous_close) / self.previous_close) * 100

class StockPrice(models.Model):
    stock = models.ForeignKey(Stock, on_delete=models.CASCADE, related_name='historical_prices')
    date = models.DateField()
    open_price = models.DecimalField(max_digits=10, decimal_places=2)
    high_price = models.DecimalField(max_digits=10, decimal_places=2)
    low_price = models.DecimalField(max_digits=10, decimal_places=2)
    close_price = models.DecimalField(max_digits=10, decimal_places=2)
    volume = models.BigIntegerField()
    
    class Meta:
        unique_together = ('stock', 'date')
        ordering = ['-date']
    
    def __str__(self):
        return f"{self.stock.symbol} - {self.date}"

class Portfolio(models.Model):
    name = models.CharField(max_length=200)
    owner = models.ForeignKey(User, on_delete=models.CASCADE, related_name='portfolios')
    description = models.TextField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    def __str__(self):
        return self.name
    
    def total_value(self):
        return sum(holding.current_value() for holding in self.holdings.all())
    
    def total_cost(self):
        return sum(holding.total_cost for holding in self.holdings.all())
    
    def total_gain_loss(self):
        return self.total_value() - self.total_cost()
    
    def total_gain_loss_percentage(self):
        if self.total_cost() == 0:
            return 0
        return (self.total_gain_loss() / self.total_cost()) * 100

class StockHolding(models.Model):
    portfolio = models.ForeignKey(Portfolio, on_delete=models.CASCADE, related_name='holdings')
    stock = models.ForeignKey(Stock, on_delete=models.CASCADE)
    shares = models.DecimalField(max_digits=10, decimal_places=2)
    average_price = models.DecimalField(max_digits=10, decimal_places=2)
    total_cost = models.DecimalField(max_digits=12, decimal_places=2)
    notes = models.TextField(blank=True, null=True)
    
    def __str__(self):
        return f"{self.portfolio.name} - {self.stock.symbol} ({self.shares} shares)"
    
    def current_value(self):
        return self.shares * self.stock.current_price
    
    def gain_loss(self):
        return self.current_value() - self.total_cost
    
    def gain_loss_percentage(self):
        if self.total_cost == 0:
            return 0
        return (self.gain_loss() / self.total_cost) * 100

class Transaction(models.Model):
    TRANSACTION_TYPES = (
        ('BUY', 'Buy'),
        ('SELL', 'Sell'),
        ('DIVIDEND', 'Dividend'),
        ('SPLIT', 'Stock Split'),
    )
    
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    portfolio = models.ForeignKey(Portfolio, on_delete=models.CASCADE, related_name='transactions')
    stock = models.ForeignKey(Stock, on_delete=models.CASCADE)
    transaction_type = models.CharField(max_length=10, choices=TRANSACTION_TYPES)
    shares = models.DecimalField(max_digits=10, decimal_places=2)
    price = models.DecimalField(max_digits=10, decimal_places=2)
    total_amount = models.DecimalField(max_digits=12, decimal_places=2)
    date = models.DateTimeField(default=timezone.now)
    notes = models.TextField(blank=True, null=True)
    
    class Meta:
        ordering = ['-date']
    
    def __str__(self):
        return f"{self.transaction_type} {self.shares} shares of {self.stock.symbol} at {self.price}"

class Watchlist(models.Model):
    name = models.CharField(max_length=100)
    owner = models.ForeignKey(User, on_delete=models.CASCADE, related_name='watchlists')
    stocks = models.ManyToManyField(Stock, related_name='watchlists')
    created_at = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return self.name
