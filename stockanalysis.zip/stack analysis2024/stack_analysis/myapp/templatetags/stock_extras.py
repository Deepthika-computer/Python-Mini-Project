from django import template
from decimal import Decimal

register = template.Library()

@register.filter
def sub(value, arg):
    """Subtract the arg from the value."""
    try:
        return value - arg
    except (ValueError, TypeError):
        return value

@register.filter
def mul(value, arg):
    """Multiply the value by the arg."""
    try:
        return value * arg
    except (ValueError, TypeError):
        return value

@register.filter
def div(value, arg):
    """Divide the value by the arg."""
    try:
        return value / arg
    except (ValueError, TypeError, ZeroDivisionError):
        return value

@register.filter
def divisibleby(value, arg):
    """Divide the value by the arg."""
    try:
        return Decimal(value) / Decimal(arg)
    except (ValueError, TypeError, ZeroDivisionError):
        return value

@register.filter
def min_value(value, arg):
    """Return the minimum of value and arg."""
    try:
        return min(value, arg)
    except (ValueError, TypeError):
        return value

@register.filter
def format_market_cap(value):
    """Format market cap in billions or millions."""
    try:
        value = int(value)
        if value >= 1000000000:
            return f"${value / 1000000000:.2f}B"
        elif value >= 1000000:
            return f"${value / 1000000:.2f}M"
        else:
            return f"${value:,}"
    except (ValueError, TypeError):
        return value

@register.filter
def filter_by_id(value, arg):
    """Filter a list of objects by ID."""
    try:
        return [item for item in value if str(item.id) == str(arg)]
    except (AttributeError, TypeError):
        return []

@register.filter
def add(value, arg):
    """Add the arg to the value."""
    try:
        return value + arg
    except (ValueError, TypeError):
        return value