from django.contrib import admin
from .models import Sector, Stock, StockPrice, Portfolio, StockHolding, Transaction, Watchlist

@admin.register(Sector)
class SectorAdmin(admin.ModelAdmin):
    list_display = ('name',)
    search_fields = ('name', 'description')

class StockPriceInline(admin.TabularInline):
    model = StockPrice
    extra = 1
    max_num = 7
    ordering = ('-date',)

@admin.register(Stock)
class StockAdmin(admin.ModelAdmin):
    list_display = ('symbol', 'name', 'sector', 'current_price', 'price_change', 'last_updated')
    list_filter = ('sector',)
    search_fields = ('symbol', 'name')
    inlines = [StockPriceInline]

@admin.register(StockPrice)
class StockPriceAdmin(admin.ModelAdmin):
    list_display = ('stock', 'date', 'open_price', 'high_price', 'low_price', 'close_price', 'volume')
    list_filter = ('date', 'stock__sector')
    search_fields = ('stock__symbol', 'stock__name')
    date_hierarchy = 'date'

class StockHoldingInline(admin.TabularInline):
    model = StockHolding
    extra = 1

class TransactionInline(admin.TabularInline):
    model = Transaction
    extra = 1
    readonly_fields = ('id',)

@admin.register(Portfolio)
class PortfolioAdmin(admin.ModelAdmin):
    list_display = ('name', 'owner', 'total_value', 'total_cost', 'total_gain_loss', 'total_gain_loss_percentage')
    search_fields = ('name', 'description', 'owner__username')
    inlines = [StockHoldingInline, TransactionInline]

@admin.register(StockHolding)
class StockHoldingAdmin(admin.ModelAdmin):
    list_display = ('portfolio', 'stock', 'shares', 'average_price', 'total_cost', 'current_value', 'gain_loss', 'gain_loss_percentage')
    list_filter = ('portfolio', 'stock__sector')
    search_fields = ('portfolio__name', 'stock__symbol', 'stock__name')

@admin.register(Transaction)
class TransactionAdmin(admin.ModelAdmin):
    list_display = ('id', 'portfolio', 'stock', 'transaction_type', 'shares', 'price', 'total_amount', 'date')
    list_filter = ('transaction_type', 'date', 'portfolio')
    search_fields = ('portfolio__name', 'stock__symbol', 'notes')
    date_hierarchy = 'date'
    readonly_fields = ('id',)

@admin.register(Watchlist)
class WatchlistAdmin(admin.ModelAdmin):
    list_display = ('name', 'owner', 'created_at')
    filter_horizontal = ('stocks',)
    search_fields = ('name', 'owner__username')
