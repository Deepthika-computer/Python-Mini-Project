from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.http import HttpResponse, JsonResponse
from django.db.models import Sum, F, ExpressionWrapper, DecimalField, Count, Q as models_Q
from django.contrib import messages
from django.utils import timezone
from decimal import Decimal
import json
from datetime import datetime, timedelta

from .models import (
    Stock, Sector, StockPrice, Portfolio, 
    StockHolding, Transaction, Watchlist
)

def home(request):
    """Home page view"""
    # Get top gainers and losers
    stocks = Stock.objects.all()
    gainers = sorted(stocks, key=lambda x: x.price_change(), reverse=True)[:5]
    losers = sorted(stocks, key=lambda x: x.price_change())[:5]
    
    # Get sector performance
    sectors = Sector.objects.all()
    for sector in sectors:
        sector_stocks = sector.stocks.all()
        if sector_stocks:
            sector.avg_change = sum(stock.price_change() for stock in sector_stocks) / sector_stocks.count()
        else:
            sector.avg_change = 0
    
    # Sort sectors by performance
    sectors = sorted(sectors, key=lambda x: x.avg_change, reverse=True)
    
    # Get recent market activity
    recent_prices = StockPrice.objects.order_by('-date')[:20]
    
    context = {
        'gainers': gainers,
        'losers': losers,
        'sectors': sectors,
        'recent_prices': recent_prices,
    }
    return render(request, 'myapp/home.html', context)

def stock_list(request):
    """View all stocks with filtering and search"""
    stocks = Stock.objects.all().order_by('symbol')
    sectors = Sector.objects.all().order_by('name')
    
    # Calculate average performance for each sector
    for sector in sectors:
        sector_stocks = sector.stocks.all()
        if sector_stocks:
            sector.avg_change = sum(stock.price_change() for stock in sector_stocks) / sector_stocks.count()
        else:
            sector.avg_change = 0
    
    # Filter by sector if provided
    sector_id = request.GET.get('sector')
    search_query = request.GET.get('search', '')
    
    if sector_id:
        stocks = stocks.filter(sector_id=sector_id)
    
    # Search by symbol or name if provided
    if search_query:
        stocks = stocks.filter(
            models_Q(symbol__icontains=search_query) | 
            models_Q(name__icontains=search_query)
        )
    
    context = {
        'stocks': stocks,
        'sectors': sectors,
        'selected_sector': sector_id,
        'search_query': search_query,
    }
    return render(request, 'myapp/stock_list.html', context)

def stock_detail(request, symbol):
    """View details for a specific stock"""
    stock = get_object_or_404(Stock, symbol=symbol)
    
    # Get historical prices for the last 30 days
    end_date = timezone.now().date()
    start_date = end_date - timedelta(days=30)
    historical_prices = stock.historical_prices.filter(date__range=[start_date, end_date]).order_by('date')
    
    # Prepare data for chart
    dates = [price.date.strftime('%Y-%m-%d') for price in historical_prices]
    prices = [float(price.close_price) for price in historical_prices]
    volumes = [price.volume for price in historical_prices]
    
    # Check if stock is in user's watchlists
    user_watchlists = []
    if request.user.is_authenticated:
        user_watchlists = request.user.watchlists.filter(stocks=stock)
    
    context = {
        'stock': stock,
        'historical_prices': historical_prices,
        'chart_dates': json.dumps(dates),
        'chart_prices': json.dumps(prices),
        'chart_volumes': json.dumps(volumes),
        'user_watchlists': user_watchlists,
    }
    return render(request, 'myapp/stock_detail.html', context)

def sector_list(request):
    """View all sectors and their performance"""
    sectors = Sector.objects.all()
    
    # Calculate average performance for each sector
    for sector in sectors:
        sector_stocks = sector.stocks.all()
        sector.stock_count = sector_stocks.count()
        if sector.stock_count > 0:
            sector.avg_change = sum(stock.price_change() for stock in sector_stocks) / sector.stock_count
        else:
            sector.avg_change = 0
    
    # Sort sectors by performance if requested
    sort_by = request.GET.get('sort', 'performance')
    if sort_by == 'performance':
        sectors = sorted(sectors, key=lambda x: x.avg_change, reverse=True)
    elif sort_by == 'name':
        sectors = sorted(sectors, key=lambda x: x.name)
    elif sort_by == 'stocks':
        sectors = sorted(sectors, key=lambda x: x.stock_count, reverse=True)
    
    context = {
        'sectors': sectors,
        'sort_by': sort_by,
    }
    return render(request, 'myapp/sector_list.html', context)

def sector_detail(request, sector_id):
    """View details for a specific sector"""
    sector = get_object_or_404(Sector, id=sector_id)
    stocks = sector.stocks.all().order_by('symbol')
    
    # Calculate sector performance
    if stocks:
        sector.avg_change = sum(stock.price_change() for stock in stocks) / stocks.count()
    else:
        sector.avg_change = 0
    
    # Sort stocks if requested
    sort_by = request.GET.get('sort', 'symbol')
    if sort_by == 'symbol':
        stocks = sorted(stocks, key=lambda x: x.symbol)
    elif sort_by == 'name':
        stocks = sorted(stocks, key=lambda x: x.name)
    elif sort_by == 'price':
        stocks = sorted(stocks, key=lambda x: x.current_price, reverse=True)
    elif sort_by == 'change':
        stocks = sorted(stocks, key=lambda x: x.price_change(), reverse=True)
    
    # Get other sectors for the related sectors section
    other_sectors = Sector.objects.exclude(id=sector_id).order_by('?')
    
    # Calculate performance for other sectors
    for other_sector in other_sectors:
        sector_stocks = other_sector.stocks.all()
        if sector_stocks:
            other_sector.avg_change = sum(stock.price_change() for stock in sector_stocks) / sector_stocks.count()
        else:
            other_sector.avg_change = 0
    
    context = {
        'sector': sector,
        'stocks': stocks,
        'sort_by': sort_by,
        'other_sectors': other_sectors,
    }
    return render(request, 'myapp/sector_detail.html', context)

@login_required
def portfolio_list(request):
    """View all portfolios for the current user"""
    portfolios = Portfolio.objects.filter(owner=request.user).order_by('-created_at')
    
    # Calculate total portfolio value
    total_value = sum(portfolio.total_value() for portfolio in portfolios)
    total_cost = sum(portfolio.total_cost() for portfolio in portfolios)
    total_gain_loss = total_value - total_cost
    
    if total_cost > 0:
        total_gain_loss_percentage = (total_gain_loss / total_cost) * 100
    else:
        total_gain_loss_percentage = 0
    
    context = {
        'portfolios': portfolios,
        'total_value': total_value,
        'total_cost': total_cost,
        'total_gain_loss': total_gain_loss,
        'total_gain_loss_percentage': total_gain_loss_percentage,
    }
    return render(request, 'myapp/portfolio_list.html', context)

@login_required
def portfolio_detail(request, portfolio_id):
    """View details for a specific portfolio"""
    portfolio = get_object_or_404(Portfolio, id=portfolio_id, owner=request.user)
    holdings = portfolio.holdings.all()
    transactions = portfolio.transactions.all()[:10]  # Get 10 most recent transactions
    
    # Calculate portfolio statistics
    total_value = portfolio.total_value()
    total_cost = portfolio.total_cost()
    total_gain_loss = portfolio.total_gain_loss()
    total_gain_loss_percentage = portfolio.total_gain_loss_percentage()
    
    # Prepare data for pie chart
    if holdings:
        holdings_data = [
            {
                'symbol': holding.stock.symbol,
                'value': float(holding.current_value()),
                'percentage': float(holding.current_value() / total_value * 100) if total_value else 0
            }
            for holding in holdings
        ]
    else:
        holdings_data = []
    
    context = {
        'portfolio': portfolio,
        'holdings': holdings,
        'transactions': transactions,
        'total_value': total_value,
        'total_cost': total_cost,
        'total_gain_loss': total_gain_loss,
        'total_gain_loss_percentage': total_gain_loss_percentage,
        'holdings_data': json.dumps(holdings_data),
    }
    return render(request, 'myapp/portfolio_detail.html', context)

@login_required
def add_portfolio(request):
    """Add a new portfolio"""
    if request.method == 'POST':
        name = request.POST.get('name')
        description = request.POST.get('description')
        
        if name:
            portfolio = Portfolio.objects.create(
                name=name,
                description=description,
                owner=request.user
            )
            messages.success(request, 'Portfolio created successfully!')
            return redirect('portfolio_detail', portfolio_id=portfolio.id)
    
    return render(request, 'myapp/add_portfolio.html')

@login_required
def add_transaction(request, portfolio_id):
    """Add a new transaction to a portfolio"""
    portfolio = get_object_or_404(Portfolio, id=portfolio_id, owner=request.user)
    stocks = Stock.objects.all().order_by('symbol')
    
    if request.method == 'POST':
        stock_id = request.POST.get('stock')
        transaction_type = request.POST.get('transaction_type')
        shares = request.POST.get('shares')
        price = request.POST.get('price')
        date = request.POST.get('date')
        notes = request.POST.get('notes', '')
        
        if stock_id and transaction_type and shares and price:
            stock = get_object_or_404(Stock, id=stock_id)
            shares = Decimal(shares)
            price = Decimal(price)
            total_amount = shares * price
            
            # Create the transaction
            transaction = Transaction.objects.create(
                portfolio=portfolio,
                stock=stock,
                transaction_type=transaction_type,
                shares=shares,
                price=price,
                total_amount=total_amount,
                date=datetime.strptime(date, '%Y-%m-%d') if date else timezone.now(),
                notes=notes
            )
            
            # Update or create the stock holding
            if transaction_type == 'BUY':
                holding, created = StockHolding.objects.get_or_create(
                    portfolio=portfolio,
                    stock=stock,
                    defaults={
                        'shares': shares,
                        'average_price': price,
                        'total_cost': total_amount
                    }
                )
                
                if not created:
                    # Update existing holding
                    total_shares = holding.shares + shares
                    total_cost = holding.total_cost + total_amount
                    holding.average_price = total_cost / total_shares if total_shares > 0 else 0
                    holding.shares = total_shares
                    holding.total_cost = total_cost
                    holding.save()
            
            elif transaction_type == 'SELL':
                try:
                    holding = StockHolding.objects.get(portfolio=portfolio, stock=stock)
                    if holding.shares >= shares:
                        holding.shares -= shares
                        holding.total_cost = holding.average_price * holding.shares
                        
                        if holding.shares == 0:
                            holding.delete()
                        else:
                            holding.save()
                    else:
                        messages.error(request, f"You don't have enough shares of {stock.symbol} to sell.")
                        return redirect('add_transaction', portfolio_id=portfolio.id)
                except StockHolding.DoesNotExist:
                    messages.error(request, f"You don't own any shares of {stock.symbol}.")
                    return redirect('add_transaction', portfolio_id=portfolio.id)
            
            messages.success(request, 'Transaction added successfully!')
            return redirect('portfolio_detail', portfolio_id=portfolio.id)
    
    context = {
        'portfolio': portfolio,
        'stocks': stocks,
    }
    return render(request, 'myapp/add_transaction.html', context)

@login_required
def watchlist_list(request):
    """View all watchlists for the current user"""
    watchlists = Watchlist.objects.filter(owner=request.user).order_by('name')
    
    context = {
        'watchlists': watchlists,
    }
    return render(request, 'myapp/watchlist_list.html', context)

@login_required
def watchlist_detail(request, watchlist_id):
    """View details for a specific watchlist"""
    watchlist = get_object_or_404(Watchlist, id=watchlist_id, owner=request.user)
    stocks = watchlist.stocks.all().order_by('symbol')
    
    context = {
        'watchlist': watchlist,
        'stocks': stocks,
    }
    return render(request, 'myapp/watchlist_detail.html', context)

@login_required
def add_watchlist(request):
    """Add a new watchlist"""
    if request.method == 'POST':
        name = request.POST.get('name')
        
        if name:
            watchlist = Watchlist.objects.create(
                name=name,
                owner=request.user
            )
            messages.success(request, 'Watchlist created successfully!')
            return redirect('watchlist_detail', watchlist_id=watchlist.id)
    
    return render(request, 'myapp/add_watchlist.html')

@login_required
def add_to_watchlist(request):
    """Add a stock to a watchlist"""
    if request.method == 'POST':
        stock_id = request.POST.get('stock_id')
        watchlist_id = request.POST.get('watchlist_id')
        
        if stock_id and watchlist_id:
            stock = get_object_or_404(Stock, id=stock_id)
            watchlist = get_object_or_404(Watchlist, id=watchlist_id, owner=request.user)
            
            watchlist.stocks.add(stock)
            
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return JsonResponse({'status': 'success'})
            
            messages.success(request, f'{stock.symbol} added to {watchlist.name}')
            return redirect('stock_detail', symbol=stock.symbol)
    
    return redirect('home')

@login_required
def remove_from_watchlist(request):
    """Remove a stock from a watchlist"""
    if request.method == 'POST':
        stock_id = request.POST.get('stock_id')
        watchlist_id = request.POST.get('watchlist_id')
        
        if stock_id and watchlist_id:
            stock = get_object_or_404(Stock, id=stock_id)
            watchlist = get_object_or_404(Watchlist, id=watchlist_id, owner=request.user)
            
            watchlist.stocks.remove(stock)
            
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return JsonResponse({'status': 'success'})
            
            messages.success(request, f'{stock.symbol} removed from {watchlist.name}')
            return redirect('watchlist_detail', watchlist_id=watchlist.id)
    
    return redirect('home')
