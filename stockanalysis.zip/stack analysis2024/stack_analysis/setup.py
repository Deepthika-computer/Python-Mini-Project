"""
Setup script to initialize the database with sample data for stock analysis.
Run this after migrations: python setup.py
"""

import os
import django
import sys
import random
from decimal import Decimal
from datetime import datetime, timedelta

# Add the project directory to the sys.path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'stack_analysis.settings')
django.setup()

from django.contrib.auth.models import User
from django.utils import timezone
from myapp.models import Sector, Stock, StockPrice, Portfolio, StockHolding, Transaction, Watchlist

def create_superuser():
    """Create a superuser if one doesn't exist"""
    if not User.objects.filter(username='admin').exists():
        User.objects.create_superuser('admin', 'admin@example.com', 'adminpassword')
        print("Superuser 'admin' created with password 'adminpassword'")
    else:
        print("Superuser 'admin' already exists")

def create_sectors():
    """Create market sectors"""
    sectors = [
        {'name': 'Technology', 'description': 'Companies that primarily develop software, hardware, semiconductors, and internet services.'},
        {'name': 'Healthcare', 'description': 'Companies involved in medical services, equipment, drugs, and insurance.'},
        {'name': 'Financial Services', 'description': 'Banks, insurance companies, credit card companies, and investment firms.'},
        {'name': 'Consumer Discretionary', 'description': 'Companies that sell non-essential goods and services that consumers purchase when they have extra income.'},
        {'name': 'Consumer Staples', 'description': 'Companies that provide essential products and services that people need regardless of economic conditions.'},
        {'name': 'Energy', 'description': 'Companies involved in the exploration, production, and distribution of oil, gas, and renewable energy.'},
        {'name': 'Industrials', 'description': 'Companies that produce machinery, equipment, and supplies used in manufacturing and construction.'},
        {'name': 'Materials', 'description': 'Companies involved in the discovery, development, and processing of raw materials.'},
        {'name': 'Utilities', 'description': 'Companies that provide essential services such as electricity, natural gas, and water.'},
        {'name': 'Real Estate', 'description': 'Companies involved in real estate development, management, and investment trusts (REITs).'},
        {'name': 'Communication Services', 'description': 'Companies that provide communication services, media, and entertainment.'},
    ]
    
    for sector_data in sectors:
        sector, created = Sector.objects.get_or_create(
            name=sector_data['name'],
            defaults={
                'description': sector_data['description']
            }
        )
        if created:
            print(f"Created sector: {sector.name}")
    
    print(f"Total sectors: {Sector.objects.count()}")

def create_stocks():
    """Create sample stocks"""
    # Get all sectors
    sectors = {sector.name: sector for sector in Sector.objects.all()}
    
    stocks = [
        # Technology
        {'symbol': 'AAPL', 'name': 'Apple Inc.', 'sector': sectors['Technology'], 
         'description': 'Apple Inc. designs, manufactures, and markets smartphones, personal computers, tablets, wearables, and accessories worldwide.',
         'current_price': Decimal('175.50'), 'previous_close': Decimal('173.25'), 'market_cap': 2800000000000,
         'pe_ratio': Decimal('28.5'), 'dividend_yield': Decimal('0.55')},
        
        {'symbol': 'MSFT', 'name': 'Microsoft Corporation', 'sector': sectors['Technology'],
         'description': 'Microsoft Corporation develops, licenses, and supports software, services, devices, and solutions worldwide.',
         'current_price': Decimal('325.75'), 'previous_close': Decimal('320.10'), 'market_cap': 2400000000000,
         'pe_ratio': Decimal('32.1'), 'dividend_yield': Decimal('0.75')},
        
        {'symbol': 'GOOGL', 'name': 'Alphabet Inc.', 'sector': sectors['Technology'],
         'description': 'Alphabet Inc. provides various products and platforms in the United States, Europe, the Middle East, Africa, the Asia-Pacific, Canada, and Latin America.',
         'current_price': Decimal('135.60'), 'previous_close': Decimal('134.25'), 'market_cap': 1700000000000,
         'pe_ratio': Decimal('25.8'), 'dividend_yield': None},
        
        {'symbol': 'AMZN', 'name': 'Amazon.com, Inc.', 'sector': sectors['Technology'],
         'description': 'Amazon.com, Inc. engages in the retail sale of consumer products and subscriptions in North America and internationally.',
         'current_price': Decimal('145.20'), 'previous_close': Decimal('142.80'), 'market_cap': 1500000000000,
         'pe_ratio': Decimal('60.2'), 'dividend_yield': None},
        
        # Healthcare
        {'symbol': 'JNJ', 'name': 'Johnson & Johnson', 'sector': sectors['Healthcare'],
         'description': 'Johnson & Johnson researches and develops, manufactures, and sells various products in the healthcare field worldwide.',
         'current_price': Decimal('155.30'), 'previous_close': Decimal('156.50'), 'market_cap': 400000000000,
         'pe_ratio': Decimal('22.1'), 'dividend_yield': Decimal('2.95')},
        
        {'symbol': 'PFE', 'name': 'Pfizer Inc.', 'sector': sectors['Healthcare'],
         'description': 'Pfizer Inc. discovers, develops, manufactures, markets, distributes, and sells biopharmaceutical products worldwide.',
         'current_price': Decimal('28.15'), 'previous_close': Decimal('28.75'), 'market_cap': 160000000000,
         'pe_ratio': Decimal('9.8'), 'dividend_yield': Decimal('5.40')},
        
        # Financial Services
        {'symbol': 'JPM', 'name': 'JPMorgan Chase & Co.', 'sector': sectors['Financial Services'],
         'description': 'JPMorgan Chase & Co. operates as a financial services company worldwide.',
         'current_price': Decimal('185.40'), 'previous_close': Decimal('182.60'), 'market_cap': 540000000000,
         'pe_ratio': Decimal('11.2'), 'dividend_yield': Decimal('2.45')},
        
        {'symbol': 'BAC', 'name': 'Bank of America Corporation', 'sector': sectors['Financial Services'],
         'description': 'Bank of America Corporation provides banking and financial products and services for individual consumers, small and middle-market businesses, institutional investors, large corporations, and governments worldwide.',
         'current_price': Decimal('37.25'), 'previous_close': Decimal('36.80'), 'market_cap': 300000000000,
         'pe_ratio': Decimal('10.5'), 'dividend_yield': Decimal('2.60')},
        
        # Consumer Discretionary
        {'symbol': 'TSLA', 'name': 'Tesla, Inc.', 'sector': sectors['Consumer Discretionary'],
         'description': 'Tesla, Inc. designs, develops, manufactures, leases, and sells electric vehicles, and energy generation and storage systems.',
         'current_price': Decimal('215.75'), 'previous_close': Decimal('220.50'), 'market_cap': 680000000000,
         'pe_ratio': Decimal('55.3'), 'dividend_yield': None},
        
        {'symbol': 'NKE', 'name': 'NIKE, Inc.', 'sector': sectors['Consumer Discretionary'],
         'description': 'NIKE, Inc. designs, develops, markets, and sells athletic footwear, apparel, equipment, and accessories worldwide.',
         'current_price': Decimal('95.40'), 'previous_close': Decimal('94.20'), 'market_cap': 145000000000,
         'pe_ratio': Decimal('28.7'), 'dividend_yield': Decimal('1.35')},
        
        # Consumer Staples
        {'symbol': 'KO', 'name': 'The Coca-Cola Company', 'sector': sectors['Consumer Staples'],
         'description': 'The Coca-Cola Company manufactures, markets, and sells various nonalcoholic beverages worldwide.',
         'current_price': Decimal('62.15'), 'previous_close': Decimal('61.80'), 'market_cap': 270000000000,
         'pe_ratio': Decimal('25.6'), 'dividend_yield': Decimal('2.85')},
        
        {'symbol': 'PG', 'name': 'The Procter & Gamble Company', 'sector': sectors['Consumer Staples'],
         'description': 'The Procter & Gamble Company provides branded consumer packaged goods to consumers in North and Latin America, Europe, the Asia Pacific, Greater China, India, the Middle East, and Africa.',
         'current_price': Decimal('155.80'), 'previous_close': Decimal('154.90'), 'market_cap': 370000000000,
         'pe_ratio': Decimal('26.2'), 'dividend_yield': Decimal('2.40')},
        
        # Energy
        {'symbol': 'XOM', 'name': 'Exxon Mobil Corporation', 'sector': sectors['Energy'],
         'description': 'Exxon Mobil Corporation explores for and produces crude oil and natural gas in the United States and internationally.',
         'current_price': Decimal('110.25'), 'previous_close': Decimal('112.30'), 'market_cap': 450000000000,
         'pe_ratio': Decimal('8.3'), 'dividend_yield': Decimal('3.60')},
        
        {'symbol': 'CVX', 'name': 'Chevron Corporation', 'sector': sectors['Energy'],
         'description': 'Chevron Corporation engages in integrated energy and chemicals operations worldwide.',
         'current_price': Decimal('155.40'), 'previous_close': Decimal('158.20'), 'market_cap': 290000000000,
         'pe_ratio': Decimal('9.1'), 'dividend_yield': Decimal('4.10')},
        
        # Industrials
        {'symbol': 'CAT', 'name': 'Caterpillar Inc.', 'sector': sectors['Industrials'],
         'description': 'Caterpillar Inc. manufactures and sells construction and mining equipment, diesel and natural gas engines, industrial gas turbines, and diesel-electric locomotives worldwide.',
         'current_price': Decimal('325.60'), 'previous_close': Decimal('320.80'), 'market_cap': 165000000000,
         'pe_ratio': Decimal('14.7'), 'dividend_yield': Decimal('1.85')},
        
        {'symbol': 'BA', 'name': 'The Boeing Company', 'sector': sectors['Industrials'],
         'description': 'The Boeing Company designs, manufactures, and sells airplanes, rotorcraft, rockets, satellites, telecommunications equipment, and missiles worldwide.',
         'current_price': Decimal('175.20'), 'previous_close': Decimal('180.50'), 'market_cap': 110000000000,
         'pe_ratio': None, 'dividend_yield': None},
        
        # Materials
        {'symbol': 'LIN', 'name': 'Linde plc', 'sector': sectors['Materials'],
         'description': 'Linde plc operates as an industrial gas company worldwide.',
         'current_price': Decimal('415.30'), 'previous_close': Decimal('412.60'), 'market_cap': 200000000000,
         'pe_ratio': Decimal('32.8'), 'dividend_yield': Decimal('1.30')},
        
        # Utilities
        {'symbol': 'NEE', 'name': 'NextEra Energy, Inc.', 'sector': sectors['Utilities'],
         'description': 'NextEra Energy, Inc. generates, transmits, distributes, and sells electric power to retail and wholesale customers in North America.',
         'current_price': Decimal('72.40'), 'previous_close': Decimal('71.80'), 'market_cap': 145000000000,
         'pe_ratio': Decimal('19.6'), 'dividend_yield': Decimal('2.75')},
        
        # Real Estate
        {'symbol': 'AMT', 'name': 'American Tower Corporation', 'sector': sectors['Real Estate'],
         'description': 'American Tower Corporation operates as a real estate investment trust that owns, operates, and develops multitenant communications real estate properties.',
         'current_price': Decimal('195.60'), 'previous_close': Decimal('193.20'), 'market_cap': 90000000000,
         'pe_ratio': Decimal('45.2'), 'dividend_yield': Decimal('3.15')},
        
        # Communication Services
        {'symbol': 'NFLX', 'name': 'Netflix, Inc.', 'sector': sectors['Communication Services'],
         'description': 'Netflix, Inc. provides entertainment services, offering TV series, documentaries, feature films, and mobile games across various genres and languages.',
         'current_price': Decimal('625.40'), 'previous_close': Decimal('610.80'), 'market_cap': 270000000000,
         'pe_ratio': Decimal('42.5'), 'dividend_yield': None},
    ]
    
    for stock_data in stocks:
        stock, created = Stock.objects.get_or_create(
            symbol=stock_data['symbol'],
            defaults={
                'name': stock_data['name'],
                'sector': stock_data['sector'],
                'description': stock_data['description'],
                'current_price': stock_data['current_price'],
                'previous_close': stock_data['previous_close'],
                'market_cap': stock_data['market_cap'],
                'pe_ratio': stock_data['pe_ratio'],
                'dividend_yield': stock_data['dividend_yield'],
                'last_updated': timezone.now()
            }
        )
        if created:
            print(f"Created stock: {stock.symbol}")
    
    print(f"Total stocks: {Stock.objects.count()}")

def create_historical_prices():
    """Create historical price data for stocks"""
    stocks = Stock.objects.all()
    end_date = timezone.now().date()
    start_date = end_date - timedelta(days=30)
    
    for stock in stocks:
        # Generate 30 days of historical data
        current_date = start_date
        previous_close = stock.current_price * Decimal(random.uniform(0.9, 1.1))
        
        while current_date <= end_date:
            # Skip weekends
            if current_date.weekday() >= 5:  # 5 = Saturday, 6 = Sunday
                current_date += timedelta(days=1)
                continue
            
            # Random daily fluctuation between -3% and +3%
            daily_change = random.uniform(-0.03, 0.03)
            open_price = previous_close
            close_price = previous_close * Decimal(1 + daily_change)
            
            # High and low prices
            high_price = max(open_price, close_price) * Decimal(random.uniform(1.001, 1.02))
            low_price = min(open_price, close_price) * Decimal(random.uniform(0.98, 0.999))
            
            # Volume (random between 1M and 20M)
            volume = random.randint(1000000, 20000000)
            
            # Create the price record
            price, created = StockPrice.objects.get_or_create(
                stock=stock,
                date=current_date,
                defaults={
                    'open_price': open_price.quantize(Decimal('0.01')),
                    'high_price': high_price.quantize(Decimal('0.01')),
                    'low_price': low_price.quantize(Decimal('0.01')),
                    'close_price': close_price.quantize(Decimal('0.01')),
                    'volume': volume
                }
            )
            
            if created and current_date.day == 1 or current_date.day == 15:
                print(f"Created price data for {stock.symbol} on {current_date}")
            
            # Set up for next day
            previous_close = close_price
            current_date += timedelta(days=1)
    
    print(f"Created historical price data for {stocks.count()} stocks")

def create_sample_portfolio():
    """Create a sample portfolio for the admin user"""
    # Get the admin user
    admin = User.objects.get(username='admin')
    
    # Create a portfolio
    portfolio, created = Portfolio.objects.get_or_create(
        name='Growth Portfolio',
        owner=admin,
        defaults={
            'description': 'A portfolio focused on high-growth technology and healthcare stocks.'
        }
    )
    
    if created:
        print(f"Created portfolio: {portfolio.name}")
        
        # Add some stocks to the portfolio
        stocks_to_add = {
            'AAPL': {'shares': Decimal('10'), 'price': Decimal('150.25')},
            'MSFT': {'shares': Decimal('5'), 'price': Decimal('290.50')},
            'AMZN': {'shares': Decimal('3'), 'price': Decimal('135.75')},
            'JNJ': {'shares': Decimal('8'), 'price': Decimal('152.30')},
        }
        
        for symbol, data in stocks_to_add.items():
            stock = Stock.objects.get(symbol=symbol)
            shares = data['shares']
            price = data['price']
            total_cost = shares * price
            
            # Create holding
            holding = StockHolding.objects.create(
                portfolio=portfolio,
                stock=stock,
                shares=shares,
                average_price=price,
                total_cost=total_cost
            )
            
            # Create buy transaction
            transaction_date = timezone.now() - timedelta(days=random.randint(1, 30))
            Transaction.objects.create(
                portfolio=portfolio,
                stock=stock,
                transaction_type='BUY',
                shares=shares,
                price=price,
                total_amount=total_cost,
                date=transaction_date,
                notes=f"Initial purchase of {symbol}"
            )
            
            print(f"Added {shares} shares of {symbol} to portfolio")
    else:
        print(f"Portfolio '{portfolio.name}' already exists")
    
    # Create a second portfolio
    portfolio2, created = Portfolio.objects.get_or_create(
        name='Dividend Income',
        owner=admin,
        defaults={
            'description': 'A portfolio focused on dividend-paying stocks for regular income.'
        }
    )
    
    if created:
        print(f"Created portfolio: {portfolio2.name}")
        
        # Add some stocks to the portfolio
        stocks_to_add = {
            'KO': {'shares': Decimal('20'), 'price': Decimal('60.15')},
            'PG': {'shares': Decimal('12'), 'price': Decimal('150.30')},
            'XOM': {'shares': Decimal('15'), 'price': Decimal('105.75')},
            'JPM': {'shares': Decimal('10'), 'price': Decimal('175.40')},
        }
        
        for symbol, data in stocks_to_add.items():
            stock = Stock.objects.get(symbol=symbol)
            shares = data['shares']
            price = data['price']
            total_cost = shares * price
            
            # Create holding
            holding = StockHolding.objects.create(
                portfolio=portfolio2,
                stock=stock,
                shares=shares,
                average_price=price,
                total_cost=total_cost
            )
            
            # Create buy transaction
            transaction_date = timezone.now() - timedelta(days=random.randint(1, 30))
            Transaction.objects.create(
                portfolio=portfolio2,
                stock=stock,
                transaction_type='BUY',
                shares=shares,
                price=price,
                total_amount=total_cost,
                date=transaction_date,
                notes=f"Initial purchase of {symbol}"
            )
            
            print(f"Added {shares} shares of {symbol} to portfolio")
    else:
        print(f"Portfolio '{portfolio2.name}' already exists")

def create_sample_watchlists():
    """Create sample watchlists for the admin user"""
    # Get the admin user
    admin = User.objects.get(username='admin')
    
    # Create watchlists
    watchlist_data = [
        {
            'name': 'Tech Stocks',
            'stocks': ['AAPL', 'MSFT', 'GOOGL', 'AMZN', 'NFLX']
        },
        {
            'name': 'Dividend Payers',
            'stocks': ['JNJ', 'PG', 'KO', 'XOM', 'JPM']
        }
    ]
    
    for data in watchlist_data:
        watchlist, created = Watchlist.objects.get_or_create(
            name=data['name'],
            owner=admin
        )
        
        if created:
            print(f"Created watchlist: {watchlist.name}")
            
            # Add stocks to the watchlist
            for symbol in data['stocks']:
                stock = Stock.objects.get(symbol=symbol)
                watchlist.stocks.add(stock)
                print(f"Added {symbol} to watchlist {watchlist.name}")
        else:
            print(f"Watchlist '{watchlist.name}' already exists")

if __name__ == '__main__':
    print("Setting up sample data for stock analysis...")
    create_superuser()
    create_sectors()
    create_stocks()
    create_historical_prices()
    create_sample_portfolio()
    create_sample_watchlists()
    print("Setup complete!")